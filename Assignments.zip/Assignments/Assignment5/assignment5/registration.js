function checkAllData()
        {
            //alert("function called");

            var uppercase = /^[A-Z]/;
            var lowercase = /^[a-z]/;
            var alLeastOneUpperCase = /.*[A-Z].*/;
            var alLeastOneDigit = /.*[0-9].*/;
            var digits = /^[0-9]/;

            var password = signup.password.value;
            var firstChar = password.charAt(0);            
            var conPassword = signup.repass.value;
            var userName = signup.username.value;
            var firstCharName = userName.charAt(0);
            var errorMessage = "";

            if(!uppercase.test(firstCharName) && !lowercase.test(firstCharName))
            {
            
                errorMessage += "Username must be start with a letter <hr/>"; 
            }

            if(userName.length < 6)
            {
               
               errorMessage += "User Name must be 6 characters long <hr/>";
            }

            if(password.length < 8)
            {
                
                errorMessage += "Password must be 8 Characters long <hr/>";
            }  

            if(!uppercase.test(firstChar) && !lowercase.test(firstChar))
            {
                errorMessage += "First Letter of Password Must be Character <hr/>";
            }

            if(!alLeastOneUpperCase.test(password))
            {
               
                errorMessage += "Password Must have at least one uppercase <hr/>";
            }

            if(!alLeastOneDigit.test(password))
            {
              
                errorMessage += "Password Must have at least one digit <hr/>";
            }

            if(conPassword != password)
            {
               
                errorMessage += "Password and retype Password Must be same <hr/>";
            }

            if(errorMessage != "")
            {
                document.getElementById("errors").innerHTML = errorMessage;
                return false;
            }
            else
            {
                document.getElementById("errors").innerHTML = "";
            }
            
        }