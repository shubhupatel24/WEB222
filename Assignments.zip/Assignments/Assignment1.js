/*
 * This is a JavaScript Scratchpad.
 *
 * Enter some JavaScript, then Right Click or choose from the Execute Menu:
 * 1. Run to evaluate the selected text (Cmd-R),
 * 2. Inspect to bring up an Object Inspector on the result (Cmd-I), or,
 * 3. Display to insert the result in a comment after the selection. (Cmd-L)
 */


/*******************************************************************************

 *                     WEB222 – Assignment 1

 * I declare that this assignment is my own work in accordance with Seneca

 * Academic Policy.  No part of this assignment has been copied manually or

 * electronically from any other source (including web sites) or distributed to

 * other students.

 *

 * Name: Shubham Patel Student ID: 115016172 Date: 30-jan-2018

 *

 ******************************************************************************/

/*****************************
 * Task 1
 *****************************/
var name = "Shubham patel", course = "6", program = "CPA", job = "have";
console.log("My name is "+name, "and I'm in " +program, "program. I'm taking "+course, "course in this semester and I "+job, "a part-time job now." )
/*****************************
 * Task 2
 *****************************/

var current_year = 2018;
var user_input = prompt("Please enter your age:");
var birth_year = current_year - user_input;
var no_of_years = prompt("Enter the number of years you expect to study in college:");
var grad_year = parseInt(no_of_years) + current_year;

console.log("You were born in the year of " + birth_year);
console.log("You will graduate from Seneca college in the year of " + grad_year);

/*****************************
 * Task 3
 *****************************/
function tempConvert(temperature, convert){
    
    if (convert === 'CF') {
         
       temperature = temperature * 9/5 + 32; 
       return temperature;
    }
    if (convert === 'FC'){
        
        temperature = (temperature - 32) * 5 / 9; 
        return temperature;
    }
}
console.log('22�C is ' + tempConvert(22,"CF"),'�F19');
console.log('76�F is ' + tempConvert(76,"FC"),'�C');
console.log('16�C is ' + tempConvert(16,"CF"),'�F');
/*****************************
 * Task 4
 *****************************/
function Numbers(min, max){
   
    var evenNums = [];
    var i;
    
    for (var i=0; i<=max+1; i++) {
        if (i === 0) {
                console.log(i +  " is even");
        }
        else if (i % 2 === 0) {
                console.log(i + " is even");   
        }
        else {
                console.log(i + " is odd");
        }
}
    return evenNums;
}

console.log('' + Numbers(0,10));

/*****************************
 * Task 5
 *****************************/
function largerNum(num1, num2){
    var greaterNum;
    num1 = parseInt(num1);
    num2 = parseInt(num2);
    if (isNaN(num1)){
        greaterNum = NaN;
    } else if (isNaN(num2)){
        greaterNum = NaN;
    } else {
        if (num1 > num2){
            greaterNum = num1;
        }
        if (num1 < num2){
            greaterNum = num2;
        }
        if (num1 === num2) {
            greaterNum = 'equal';
        }
    }
    return greaterNum;   
       
}

console.log('The larger number of 5 and 12 is ' + largerNum(5,12));
console.log('The larger number of 234 and 162 is ' + largerNum(234,162));

console.log("\n");
/*****************************
 * Task 6
 *****************************/
function evaluator(){
    var averag = 0;
    var i;
    for (i = 0; i < arguments.length; i += 1){
        
        averag = averag + arguments[i];
    }
    averag = averag / arguments.length;
    if (averag >= 50){
        return true;
    }
    else{
        return false;
    }
}
console.log('evaluator(50,50,50) returns: ' + evaluator(50,50,50));
console.log('evaluator(33,21,16) returns: ' + evaluator(33,21,16));
console.log('evaluator(50,49) returns: ' + evaluator(50,49));


/*****************************
 * Task 7
 *****************************/
function grader(mark){
    var studentGrade = parseInt(mark);
    //A,B,C,D = A 100-80%; B 79-70; C 69 - 60; D 59 - 50; D = 49-0;
    
    if (studentGrade >= 80 && studentGrade <= 100){
        studentGrade = 'A';
    } else if (studentGrade >= 70 && studentGrade <= 79){
        studentGrade = 'B';
    } else if (studentGrade >= 60 && studentGrade <= 69){
        studentGrade = 'C';
    } else if (studentGrade >= 50 && studentGrade <= 59){
        studentGrade = 'D';
    } else {
        studentGrade = 'F';
    }
    return studentGrade; 
}
console.log('grader(98) returns: ' + grader(98));
console.log('grader(74) returns: ' + grader(74));
console.log('grader(53) returns: ' + grader(53));




/*****************************
 * Task 8
 *****************************/
function showMultiples(num, numMultiples){
    var output = [];
    var i;
    num = parseInt(num);
    numMultiples = parseInt(numMultiples);
    for (i = 1; i < (numMultiples+1); i += 1){
        output[i-1] = (num + ' x ' + i + ' = ' + num*i + '\n');
    }
    output = output.join(''); //removes commas
    return output;
}

console.log('' + showMultiples(5,4));

/*
Exception: SyntaxError: missing ; before statement
@Scratchpad/2:10
*/
/*
Exception: SyntaxError: missing ; before statement
@Scratchpad/2:10
*/