// Data for the "HTML Lists" Page

var fruits = [ "Apples","Oranges","Pears","Grapes","Pineapples","Mangos" ];
var fruites = document.getElementById('fruites')

fruites.addEventListener('click', ()=> {
  console.log('clicked')
});

var list = document.createElement('OL')
for(var i = 0; i < fruits.length; i++){
  var _list = document.createElement('li')
  _list.innerHTML = fruits[i]
  list.appendChild(_list)
}

fruites.appendChild(list)

var directory = [
    {
      type: "file",
      name: "file1.txt"
    },
    {
      type: "file",
      name: "file2.txt"
    },
    {
      type: "directory",
      name: "HTML Files",
      files: [
        {
          type: "file",
          name: "file1.html"},
        {
          type: "file",
          name: "file2.html"
        }
      ]
    },
    {
      type: "file",
      name: "file3.txt"
    },
    {
      type: "directory",
      name: "JavaScript Files",
      files: [
        {
          type: "file",
          name: "file1.js"
        },
        {
          type: "file",
          name: "file2.js"
        },
        {
          type: "file",
          name: "file3.js"
        }
      ]
    }
];

window.addEventListener('load',() => {


  var section = document.querySelector('section')                 //refer to section tag
  var header = document.createElement('H4')                       //create new h4 element
  header.innerHTML = "Directories"                                //insert content in h4
  var div = document.createElement('DIV')                         //create Div container
  var unorderedList = document.createElement('UL')                // create unordered list container
  section.appendChild(div)                                        //insert div in section
  div.appendChild(header)                                         //insert header in div
  div.appendChild(unorderedList)                                  //insert unordered list in div


  for(var i = 0; i < directory.length; i++){                      //iterate over directory object
    // console.log(directory[i].name)
    var UlList =document.createElement('li')                      //create new list element tag
    unorderedList.appendChild(UlList)                             //insert list element in unordered list container

    if(directory[i].type === "directory"){                        // check if typ is of directory

      var file = directory[i].files.length                        //get length of file array
      var count = 0
      var ul = document.createElement('UL')                       // create unordered list tag
      UlList.innerHTML = directory[i].name
      UlList.appendChild(ul)                                      //insert secondary unordered list into primary unordered list

      do{
        var li = document.createElement('li')                     //create list element

        li.innerHTML = directory[i].files[count].name             //insert file name in secondary list element
        ul.appendChild(li)                                        //insert secondary list in seconday unordered list container
        count++
      }while(count < file)

      unorderedList.appendChild(UlList)                           //insert seconday unordered list in primary ul

    }else if(directory[i].type == 'file'){
      UlList.innerHTML = directory[i].name
    }

  }



})
